# Priyadharshini — Portfolio Website

A professional React portfolio website with smooth animations, dark theme, and fully responsive design.

## 🚀 Getting Started

### Prerequisites
- Node.js (v16 or above)
- npm or yarn

### Installation & Run

```bash
# Step 1: Install dependencies
npm install

# Step 2: Start development server
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
```

---

## 📁 Project Structure

```
src/
├── components/
│   ├── Navbar.js / Navbar.css       → Fixed navigation bar
│   ├── Hero.js / Hero.css           → Landing hero section
│   ├── About.js / About.css         → About me section
│   ├── Skills.js / Skills.css       → Animated skill bars
│   ├── Projects.js / Projects.css   → Project cards
│   ├── Experience.js / Experience.css → Timeline
│   ├── Contact.js / Contact.css     → Contact form
│   ├── Footer.js / Footer.css       → Footer
│   └── Section.css                  → Shared section styles
├── data/
│   └── data.js                      → ✏️ Edit your info here!
├── hooks/
│   └── useInView.js                 → Scroll animation hook
├── App.js
├── index.js
└── index.css
```

---

## ✏️ How to Customize

### 1. Update Your Info
Edit `src/data/data.js`:
- Change **SKILLS** with your actual skill levels
- Update **PROJECTS** with your real projects (title, desc, tech, live/code links)
- Update **EXPERIENCE** with your actual work history

### 2. Update Contact Details
In `src/components/Contact.js`, update:
- Email address
- Location
- Social media links

### 3. Add Your Photo
Replace the `"P"` initial in `Hero.js` and `About.js` with an `<img>` tag pointing to your photo.

### 4. Add Resume
Place your resume PDF at `public/resume.pdf` so the "Download CV" button works.

---

## 🎨 Tech Stack
- **React 18** — UI Framework
- **CSS Modules** — Component-scoped styles
- **Google Fonts** — Playfair Display + DM Sans
- **IntersectionObserver** — Scroll animations
- **Create React App** — Project scaffold

---

## 🌐 Deploy

### Netlify (easiest)
1. Run `npm run build`
2. Drag the `build/` folder to [netlify.com/drop](https://netlify.com/drop)

### Vercel
```bash
npm install -g vercel
vercel
```

### GitHub Pages
```bash
npm install gh-pages --save-dev
# Add to package.json: "homepage": "https://yourusername.github.io/portfolio"
npm run build && npx gh-pages -d build
```

---

Made with ❤️ by **Priyadharshini**
