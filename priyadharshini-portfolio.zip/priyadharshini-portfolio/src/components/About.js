import React, { useRef } from 'react';
import useInView from '../hooks/useInView';
import './About.css';

export default function About() {
  const ref = useRef();
  const inView = useInView(ref);

  return (
    <section id="About" className="section about" ref={ref}>
      <div className={`section__inner ${inView ? 'visible' : ''}`}>
        <div className="section__head">
          <p className="section__label">Who I Am</p>
          <h2 className="section__title">About Me</h2>
          <div className="section__line" />
        </div>

        <div className="about__grid">
          {/* Avatar */}
          <div className="about__avatar-wrap">
            <div className="about__avatar-ring">
              <div className="about__avatar">P</div>
            </div>
            <div className="about__badge about__badge--1">💻 Developer</div>
            <div className="about__badge about__badge--2">🎨 Designer</div>
          </div>

          {/* Text */}
          <div className="about__text">
            <h3 className="about__greeting">Hi, I'm Priyadharshini 👋</h3>
            <p className="about__para">
              I'm a passionate Full Stack Developer who loves crafting elegant digital
              experiences. With expertise in React and the MERN stack, I build applications
              that are not just functional but genuinely delightful to use.
            </p>
            <p className="about__para">
              When I'm not coding, you'll find me exploring UI design trends, contributing
              to open source, or writing tech articles to help the community grow.
            </p>

            {/* Info chips */}
            <div className="about__chips">
              {[['🎓', 'B.E. Computer Science'], ['📍', 'Tamil Nadu, India'], ['💼', 'Open to Work'], ['🌐', 'Remote Friendly']].map(([icon, text]) => (
                <span key={text} className="about__chip">{icon} {text}</span>
              ))}
            </div>

            <div className="about__actions">
              <a href="/resume.pdf" download className="btn btn--primary">Download CV ↓</a>
              <button className="btn btn--outline" onClick={() => document.getElementById('Contact')?.scrollIntoView({ behavior: 'smooth' })}>
                Let's Talk
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
