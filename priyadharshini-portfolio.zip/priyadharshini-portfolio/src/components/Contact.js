import React, { useRef, useState } from 'react';
import useInView from '../hooks/useInView';
import './Contact.css';

export default function Contact() {
  const ref = useRef();
  const inView = useInView(ref);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim())    e.name    = 'Name is required';
    if (!form.email.trim())   e.email   = 'Email is required';
    if (!form.subject.trim()) e.subject = 'Subject is required';
    if (!form.message.trim()) e.message = 'Message is required';
    return e;
  };

  const handleSubmit = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setSent(true);
  };

  const update = (field) => (ev) => {
    setForm({ ...form, [field]: ev.target.value });
    if (errors[field]) setErrors({ ...errors, [field]: '' });
  };

  return (
    <section id="Contact" className="section contact" ref={ref}>
      <div className={`section__inner ${inView ? 'visible' : ''}`}>
        <div className="section__head">
          <p className="section__label">Get In Touch</p>
          <h2 className="section__title">Contact Me</h2>
          <div className="section__line" />
        </div>

        <div className="contact__layout">
          {/* Info */}
          <div className="contact__info">
            <h3 className="contact__info-title">Let's work together!</h3>
            <p className="contact__info-desc">
              Have a project in mind? Want to discuss an opportunity? Or just want to say
              hello? My inbox is always open.
            </p>
            <div className="contact__details">
              {[
                ['📧', 'Email', 'priyadharshini@email.com'],
                ['📍', 'Location', 'Tamil Nadu, India'],
                ['🕐', 'Response Time', 'Within 24 hours'],
                ['💼', 'Status', 'Open to Work'],
              ].map(([icon, label, value]) => (
                <div key={label} className="contact__detail">
                  <span className="contact__detail-icon">{icon}</span>
                  <div>
                    <p className="contact__detail-label">{label}</p>
                    <p className="contact__detail-value">{value}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="contact__social">
              {[['GitHub','🐙','#'],['LinkedIn','💼','#'],['Twitter','🐦','#']].map(([name,icon,href]) => (
                <a key={name} href={href} className="contact__social-link">
                  {icon} {name}
                </a>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="contact__form-wrap">
            {sent ? (
              <div className="contact__success">
                <div className="contact__success-icon">🎉</div>
                <h3>Message Sent!</h3>
                <p>Thank you, Priyadharshini will get back to you within 24 hours.</p>
                <button className="btn btn--primary" onClick={() => { setSent(false); setForm({ name:'',email:'',subject:'',message:'' }); }}>
                  Send Another
                </button>
              </div>
            ) : (
              <div className="contact__form">
                <div className="contact__form-row">
                  <div className="contact__field">
                    <label className="contact__label">Your Name</label>
                    <input className={`contact__input ${errors.name ? 'error' : ''}`} placeholder="John Doe" value={form.name} onChange={update('name')} />
                    {errors.name && <span className="contact__error">{errors.name}</span>}
                  </div>
                  <div className="contact__field">
                    <label className="contact__label">Email Address</label>
                    <input className={`contact__input ${errors.email ? 'error' : ''}`} placeholder="john@example.com" value={form.email} onChange={update('email')} />
                    {errors.email && <span className="contact__error">{errors.email}</span>}
                  </div>
                </div>
                <div className="contact__field">
                  <label className="contact__label">Subject</label>
                  <input className={`contact__input ${errors.subject ? 'error' : ''}`} placeholder="Project Inquiry" value={form.subject} onChange={update('subject')} />
                  {errors.subject && <span className="contact__error">{errors.subject}</span>}
                </div>
                <div className="contact__field">
                  <label className="contact__label">Message</label>
                  <textarea className={`contact__input contact__textarea ${errors.message ? 'error' : ''}`} placeholder="Tell me about your project..." value={form.message} onChange={update('message')} />
                  {errors.message && <span className="contact__error">{errors.message}</span>}
                </div>
                <button className="btn btn--primary contact__submit" onClick={handleSubmit}>
                  Send Message ✦
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
