import React, { useRef } from 'react';
import { EXPERIENCE } from '../data/data';
import useInView from '../hooks/useInView';
import './Experience.css';

export default function Experience() {
  const ref = useRef();
  const inView = useInView(ref);

  return (
    <section id="Experience" className="section experience" ref={ref}>
      <div className={`section__inner ${inView ? 'visible' : ''}`}>
        <div className="section__head">
          <p className="section__label">Journey</p>
          <h2 className="section__title">Work Experience</h2>
          <div className="section__line" />
        </div>

        <div className="timeline">
          <div className="timeline__line" />
          {EXPERIENCE.map((exp, i) => (
            <div key={i} className="timeline__item" style={{ animationDelay: `${i * 0.15}s` }}>
              <div className="timeline__dot">{exp.icon}</div>
              <div className="timeline__card">
                <div className="timeline__card-top">
                  <h3 className="timeline__role">{exp.role}</h3>
                  <span className="timeline__period">{exp.period}</span>
                </div>
                <p className="timeline__company">{exp.company}</p>
                <p className="timeline__desc">{exp.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
