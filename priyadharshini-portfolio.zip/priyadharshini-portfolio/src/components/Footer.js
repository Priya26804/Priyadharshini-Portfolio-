import React from 'react';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__top">
        <div className="footer__logo">Priya<span className="accent">.</span></div>
        <p className="footer__tagline">Building the web, one component at a time.</p>
        <div className="footer__social">
          {[['GitHub','🐙','#'],['LinkedIn','💼','#'],['Twitter','🐦','#']].map(([name,icon,href]) => (
            <a key={name} href={href} className="footer__social-link">{icon} {name}</a>
          ))}
        </div>
      </div>
      <div className="footer__bottom">
        <p>
          Designed & Developed by{' '}
          <span className="accent" style={{ fontWeight: 600 }}>Priyadharshini</span>
          {' '}· {new Date().getFullYear()} · Built with React ⚛️
        </p>
      </div>
    </footer>
  );
}
