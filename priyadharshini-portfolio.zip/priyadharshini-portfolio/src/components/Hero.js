import React, { useState, useEffect } from 'react';
import { TYPEWRITER_WORDS, SOCIAL } from '../data/data';
import './Hero.css';

function TypeWriter({ words }) {
  const [text, setText] = useState('');
  const [wIdx, setWIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[wIdx];
    const speed = deleting ? 60 : 100;
    const timer = setTimeout(() => {
      if (!deleting && charIdx < word.length) {
        setText(word.slice(0, charIdx + 1));
        setCharIdx(c => c + 1);
      } else if (!deleting && charIdx === word.length) {
        setTimeout(() => setDeleting(true), 1400);
      } else if (deleting && charIdx > 0) {
        setText(word.slice(0, charIdx - 1));
        setCharIdx(c => c - 1);
      } else {
        setDeleting(false);
        setWIdx(i => (i + 1) % words.length);
      }
    }, speed);
    return () => clearTimeout(timer);
  }, [text, charIdx, deleting, wIdx, words]);

  return (
    <span className="typewriter">
      {text}
      <span className="typewriter__cursor" />
    </span>
  );
}

export default function Hero() {
  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="Home" className="hero">
      {/* Background orbs */}
      <div className="hero__orb hero__orb--1" />
      <div className="hero__orb hero__orb--2" />
      <div className="hero__orb hero__orb--3" />

      <div className="hero__content fade-up">
        {/* Status badge */}
        <div className="hero__badge">
          <span className="hero__badge-dot" />
          Available for hire
        </div>

        <h1 className="hero__name">Priyadharshini</h1>

        <p className="hero__subtitle">
          I am a <TypeWriter words={TYPEWRITER_WORDS} />
        </p>

        <p className="hero__desc">
          Passionate about building fast, beautiful, and accessible web
          experiences that users love and businesses trust.
        </p>

        <div className="hero__btns">
          <button className="btn btn--primary hero__btn" onClick={() => scrollTo('Projects')}>
            View My Work →
          </button>
          <button className="btn btn--outline hero__btn" onClick={() => scrollTo('Contact')}>
            Contact Me
          </button>
        </div>

        {/* Social links */}
        <div className="hero__social">
          {SOCIAL.map(s => (
            <a key={s.label} href={s.href} className="hero__social-link">
              {s.icon} {s.label}
            </a>
          ))}
        </div>

        {/* Stats */}
        <div className="hero__stats">
          {[['3+', 'Years Exp.'], ['20+', 'Projects'], ['10+', 'Happy Clients']].map(([num, label]) => (
            <div key={label} className="hero__stat">
              <span className="hero__stat-num">{num}</span>
              <span className="hero__stat-label">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Avatar */}
      <div className="hero__avatar-wrap fade-up">
        <div className="hero__avatar-ring">
          <div className="hero__avatar">P</div>
        </div>
        <div className="hero__float-badge hero__float-badge--1">⚛️ React</div>
        <div className="hero__float-badge hero__float-badge--2">🟢 Open to Work</div>
        <div className="hero__float-badge hero__float-badge--3">🚀 3+ Yrs Exp</div>
      </div>
    </section>
  );
}
