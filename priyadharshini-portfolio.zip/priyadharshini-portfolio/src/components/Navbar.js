import React, { useState, useEffect } from 'react';
import { NAV_LINKS } from '../data/data';
import './Navbar.css';

export default function Navbar() {
  const [activeNav, setActiveNav] = useState('Home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);
      NAV_LINKS.forEach(n => {
        const el = document.getElementById(n);
        if (!el) return;
        const { top } = el.getBoundingClientRect();
        if (top <= 120) setActiveNav(n);
      });
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
  };

  return (
    <>
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
        <div className="navbar__logo" onClick={() => scrollTo('Home')}>
          Priya<span className="accent">.</span>
        </div>

        {/* Desktop Links */}
        <div className="navbar__links desktop-only">
          {NAV_LINKS.map(n => (
            <button
              key={n}
              className={`navbar__link ${activeNav === n ? 'active' : ''}`}
              onClick={() => scrollTo(n)}
            >
              {n}
            </button>
          ))}
        </div>

        <a href="#Contact" className="btn btn--primary desktop-only" onClick={e => { e.preventDefault(); scrollTo('Contact'); }}>
          Hire Me
        </a>

        {/* Hamburger */}
        <button className="hamburger" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? '✕' : '☰'}
        </button>
      </nav>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="mobile-menu">
          {NAV_LINKS.map(n => (
            <button key={n} className="mobile-menu__link" onClick={() => scrollTo(n)}>
              {n}
            </button>
          ))}
        </div>
      )}
    </>
  );
}
