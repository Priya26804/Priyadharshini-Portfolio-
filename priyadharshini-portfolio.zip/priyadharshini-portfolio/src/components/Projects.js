import React, { useRef, useState } from 'react';
import { PROJECTS } from '../data/data';
import useInView from '../hooks/useInView';
import './Projects.css';

function ProjectCard({ project }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className={`project-card ${hovered ? 'hovered' : ''}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ '--card-glow': project.gradient }}
    >
      <div className="project-card__strip" style={{ background: project.gradient }} />
      <div className="project-card__body">
        <div className="project-card__top">
          <span className="project-card__category">{project.category}</span>
        </div>
        <h3 className="project-card__title">{project.title}</h3>
        <p className="project-card__desc">{project.desc}</p>
        <div className="project-card__tech">
          {project.tech.map(t => (
            <span key={t} className="project-card__tech-tag">{t}</span>
          ))}
        </div>
        <div className="project-card__links">
          <a href={project.live} className="btn btn--primary project-card__btn">Live Demo ↗</a>
          <a href={project.code} className="btn btn--outline project-card__btn">Source Code</a>
        </div>
      </div>
    </div>
  );
}

export default function Projects() {
  const ref = useRef();
  const inView = useInView(ref);

  return (
    <section id="Projects" className="section projects" ref={ref}>
      <div className={`section__inner ${inView ? 'visible' : ''}`}>
        <div className="section__head">
          <p className="section__label">Portfolio</p>
          <h2 className="section__title">Featured Projects</h2>
          <div className="section__line" />
        </div>

        <div className="projects__grid">
          {PROJECTS.map(p => <ProjectCard key={p.id} project={p} />)}
        </div>
      </div>
    </section>
  );
}
