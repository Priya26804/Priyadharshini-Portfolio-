import React, { useRef } from 'react';
import { SKILLS, EXTRA_SKILLS } from '../data/data';
import useInView from '../hooks/useInView';
import './Skills.css';

function SkillBar({ skill, animate }) {
  return (
    <div className="skill-bar">
      <div className="skill-bar__header">
        <span className="skill-bar__name">{skill.name}</span>
        <span className="skill-bar__percent" style={{ color: skill.color }}>{skill.level}%</span>
      </div>
      <div className="skill-bar__track">
        <div
          className="skill-bar__fill"
          style={{
            width: animate ? `${skill.level}%` : '0%',
            background: `linear-gradient(90deg, ${skill.color}88, ${skill.color})`,
          }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const ref = useRef();
  const inView = useInView(ref);

  return (
    <section id="Skills" className="section skills" ref={ref}>
      <div className={`section__inner ${inView ? 'visible' : ''}`}>
        <div className="section__head">
          <p className="section__label">Expertise</p>
          <h2 className="section__title">Skills & Technologies</h2>
          <div className="section__line" />
        </div>

        <div className="skills__grid">
          {SKILLS.map(s => <SkillBar key={s.name} skill={s} animate={inView} />)}
        </div>

        <div className="skills__extras">
          {EXTRA_SKILLS.map(t => (
            <span key={t} className="skills__extra-chip">{t}</span>
          ))}
        </div>
      </div>
    </section>
  );
}
