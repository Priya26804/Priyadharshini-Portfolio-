export const NAV_LINKS = ['Home', 'About', 'Skills', 'Projects', 'Experience', 'Contact'];

export const SKILLS = [
  { name: 'React.js',     level: 90, color: '#61DAFB' },
  { name: 'JavaScript',   level: 85, color: '#F7DF1E' },
  { name: 'HTML & CSS',   level: 95, color: '#E34F26' },
  { name: 'Node.js',      level: 78, color: '#68A063' },
  { name: 'MongoDB',      level: 72, color: '#4DB33D' },
  { name: 'Tailwind CSS', level: 88, color: '#38BDF8' },
  { name: 'Git & GitHub', level: 82, color: '#F05032' },
  { name: 'Figma',        level: 70, color: '#F24E1E' },
];

export const EXTRA_SKILLS = [
  'REST APIs', 'Redux', 'TypeScript', 'Docker',
  'AWS', 'PostgreSQL', 'Socket.io', 'Jest Testing',
];

export const PROJECTS = [
  {
    id: 1,
    title: 'ShopEase',
    category: 'Full Stack',
    desc: 'A complete e-commerce platform with product management, cart system, user authentication, and Razorpay payment gateway.',
    tech: ['React', 'Node.js', 'MongoDB', 'Express'],
    live: '#',
    code: '#',
    gradient: 'linear-gradient(135deg,#f093fb,#f5576c)',
  },
  {
    id: 2,
    title: 'TaskFlow',
    category: 'Productivity',
    desc: 'Kanban-style task management app with drag-and-drop boards, team collaboration, real-time updates, and deadline tracking.',
    tech: ['React', 'Firebase', 'Tailwind CSS'],
    live: '#',
    code: '#',
    gradient: 'linear-gradient(135deg,#4facfe,#00f2fe)',
  },
  {
    id: 3,
    title: 'WeatherNow',
    category: 'API Project',
    desc: 'Real-time weather dashboard with beautiful visualisations, 7-day forecast, and location-based search powered by OpenWeather API.',
    tech: ['JavaScript', 'Chart.js', 'OpenWeather API'],
    live: '#',
    code: '#',
    gradient: 'linear-gradient(135deg,#43e97b,#38f9d7)',
  },
  {
    id: 4,
    title: 'DevBlog',
    category: 'Content Platform',
    desc: 'A developer blog platform with Markdown editor, syntax highlighting, tag filtering, and comment system.',
    tech: ['React', 'Node.js', 'MySQL'],
    live: '#',
    code: '#',
    gradient: 'linear-gradient(135deg,#fa709a,#fee140)',
  },
];

export const EXPERIENCE = [
  {
    role: 'Frontend Developer Intern',
    company: 'Tech Solutions Pvt Ltd',
    period: 'Jan 2024 – Jun 2024',
    desc: 'Built responsive UI components in React, collaborated with design team using Figma, improved page load performance by 35%.',
    icon: '💼',
  },
  {
    role: 'Web Development Trainee',
    company: 'CodeCraft Academy',
    period: 'Jul 2023 – Dec 2023',
    desc: 'Completed intensive full-stack training covering MERN stack, REST APIs, and deployment on AWS.',
    icon: '🎓',
  },
];

export const SOCIAL = [
  { label: 'GitHub',    href: '#', icon: '🐙' },
  { label: 'LinkedIn',  href: '#', icon: '💼' },
  { label: 'Twitter',   href: '#', icon: '🐦' },
];

export const TYPEWRITER_WORDS = [
  'Frontend Developer',
  'React Specialist',
  'UI Designer',
  'Full Stack Dev',
];
